/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50621
Source Host           : localhost:3306
Source Database       : samp

Target Server Type    : MYSQL
Target Server Version : 50621
File Encoding         : 65001

Date: 2015-02-15 15:51:32
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `chat`
-- ----------------------------
DROP TABLE IF EXISTS `chat`;
CREATE TABLE `chat` (
  `chatId` bigint(20) NOT NULL AUTO_INCREMENT,
  `cText` text,
  `name` varchar(256) NOT NULL,
  `cDate` datetime NOT NULL,
  PRIMARY KEY (`chatId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of chat
-- ----------------------------

-- ----------------------------
-- Table structure for `operate`
-- ----------------------------
DROP TABLE IF EXISTS `operate`;
CREATE TABLE `operate` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `name` varchar(256) NOT NULL,
  `ip` varchar(32) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `index_name` (`name`),
  CONSTRAINT `test` FOREIGN KEY (`name`) REFERENCES `player` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=288 DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of operate
-- ----------------------------

-- ----------------------------
-- Table structure for `player`
-- ----------------------------
DROP TABLE IF EXISTS `player`;
CREATE TABLE `player` (
  `name` varchar(256) NOT NULL,
  `password` varchar(64) NOT NULL,
  `sex` varchar(2) NOT NULL,
  `skin` int(11) NOT NULL,
  `age` int(11) NOT NULL,
  `month` int(11) NOT NULL,
  `money` bigint(20) NOT NULL,
  `gm` int(11) NOT NULL,
  `worldID` int(11) NOT NULL,
  `interiorID` int(11) NOT NULL,
  `x` float(10,5) NOT NULL,
  `y` float(10,5) NOT NULL,
  `z` float(10,5) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of player
-- ----------------------------
INSERT INTO `player` VALUES ('Gangs_XM', 'e10adc3949ba59abbe56e057f20f883e', '女', '12', '16', '0', '5000', '0', '0', '0', '1548.84070', '-2218.46265', '13.54688');
INSERT INTO `player` VALUES ('Gangs_XM2412', 'd41d8cd98f00b204e9800998ecf8427e', '男', '26', '16', '0', '5000', '0', '0', '0', '1612.78711', '-2332.18994', '13.53850');
INSERT INTO `player` VALUES ('Gangs_XM24122', 'd41d8cd98f00b204e9800998ecf8427e', '男', '26', '16', '0', '5000', '0', '0', '0', '1612.78711', '-2332.18994', '13.53850');
INSERT INTO `player` VALUES ('Gangs_XM241221', 'e10adc3949ba59abbe56e057f20f883e', '男', '26', '16', '0', '5000', '0', '0', '0', '162.14035', '-71.74956', '1.63708');
INSERT INTO `player` VALUES ('Gangs_XM2412212', 'e10adc3949ba59abbe56e057f20f883e', '男', '26', '16', '0', '5000', '0', '0', '0', '835.95325', '-2022.61560', '12.86719');

-- ----------------------------
-- Table structure for `vehicle`
-- ----------------------------
DROP TABLE IF EXISTS `vehicle`;
CREATE TABLE `vehicle` (
  `ID` bigint(20) NOT NULL,
  `type` int(11) NOT NULL,
  `model` int(11) NOT NULL,
  `color1` int(11) NOT NULL,
  `color2` int(11) NOT NULL,
  `owner` varchar(256) NOT NULL,
  `price` int(11) NOT NULL,
  `License` varchar(32) NOT NULL,
  `x` float(10,5) NOT NULL,
  `y` float(10,5) NOT NULL,
  `z` float(10,5) NOT NULL,
  `angle` float(10,5) NOT NULL,
  `durabillty` float(5,1) NOT NULL,
  `fuel` int(11) NOT NULL,
  `engine` int(11) NOT NULL,
  `lights` int(11) NOT NULL,
  `alarm` int(11) NOT NULL,
  `doors` int(11) NOT NULL,
  `boonnet` int(11) NOT NULL,
  `trunk` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  KEY `index_name` (`owner`),
  CONSTRAINT `test2` FOREIGN KEY (`owner`) REFERENCES `player` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of vehicle
-- ----------------------------
INSERT INTO `vehicle` VALUES ('1', '0', '400', '0', '0', 'Gangs_XM2412212', '0', '粤A 04210', '164.54695', '-72.86426', '6.42969', '0.00000', '1000.0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `vehicle` VALUES ('2', '0', '411', '0', '0', 'Gangs_XM', '0', '粤A 65939', '1615.39771', '-2316.66333', '18.37680', '0.00000', '1000.0', '100', '0', '0', '0', '0', '0', '1');

-- ----------------------------
-- Function structure for `GetHouse`
-- ----------------------------
DROP FUNCTION IF EXISTS `GetHouse`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `GetHouse`(id bigint) RETURNS text CHARSET gbk
begin
    declare result text;
    set result=(select houseId from House where houseId = id);
    return result;
end
;;
DELIMITER ;
