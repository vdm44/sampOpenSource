/*
Multi-Language system for Deadly Combinations GM
by Devastator
*/
In order to add new languages follow the steps below carefully.

1- Increase in 1 the number of MAX_LANGAGUES define, which can be found somewhere near the top of the script.
2- Add a new line in "Languages" array following the pattern: {"Example Language", "example.lang"} like the ones above.
3- Make a copy of the file "default.lang" in this folder and rename it to the language file you specificied on the step above. ("example.lang")


Now you can edit the language file you just renamed as you wish, like this:

English String (Don't edit this one!) => Translated string

Example:
"This is an english message" => "Est� � uma mensagem em ingl�s"



In case there are arguments (%s or %d) in the string, you must not change their orders. 
Example:
"A string: '%s' - A number: '%d'" => "Uma mensagem: '%s' - Um n�mero '%d'"


Important:
- Remember always to leave the first string as it is and only edit the string AFTER '=>'.
- Never edit "default.lang"
- Don't remove any ' in the strings as they are the identifiers of the coming argument. 
- If you don't know what a string means or where its from, just leave it.
