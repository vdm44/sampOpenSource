/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50090
Source Host           : localhost:3306
Source Database       : samp

Target Server Type    : MYSQL
Target Server Version : 50090
File Encoding         : 65001

Date: 2014-02-13 21:49:00
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `players`
-- ----------------------------
DROP TABLE IF EXISTS `players`;
CREATE TABLE `players` (
  `id` int(32) NOT NULL auto_increment,
  `name` varchar(256) character set latin1 NOT NULL,
  `code` varchar(256) character set latin1 NOT NULL,
  `email` varchar(256) character set latin1 NOT NULL,
  `yz` int(32) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records of players
-- ----------------------------
INSERT INTO `players` VALUES ('1', 'xiao_mi', '43008', '851321530@qq.com', '1');
